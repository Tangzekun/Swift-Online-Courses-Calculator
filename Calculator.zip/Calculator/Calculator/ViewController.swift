//
//  ViewController.swift
//  Calculator
//
//  Created by TangZekun on 12/27/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var display: UILabel!
    
    @IBAction func nuberPressed(sender: AnyObject)
    {
        let digit = sender.currentTitle!
        
        if userIsTyping
        {
          self.display.text = display.text! + digit!
        }
        else
        {
            self.display.text = digit
            userIsTyping = true
        }
        
        
    }
    
    var operandStack = Array<Double>()
    var userIsTyping = false
    
    @IBAction func returnButtonPressed()
    {
        operandStack.append(displayValue)
        print(operandStack)
        userIsTyping = false
    }
    
    var displayValue : Double
    {
        get
        {
           return  NSNumberFormatter().numberFromString(self.display.text!)!.doubleValue
        }
        set
        {
            self.display.text = "\(newValue)"
            userIsTyping = false
        }
    }
    
    @IBAction func clearButtonPressend(sender: AnyObject)
    {
        operandStack.removeAll()
        self.display.text = "0"
        userIsTyping = false
    }
    
    
    @IBAction func calcuationButtonPressed(sender: AnyObject)
    {
        let operation = sender.currentTitle!
        if userIsTyping
        {
            returnButtonPressed()
        }
        
        switch operation
        {
            case "×"?:
            
            //doCaluculation({(op1: Double, op2: Double) -> Double in return op1 * op2 })
            //doCalculation({(op1, op2) in return op1 * op2 })
             doCalculation {$0 * $1}
            
            case "÷"?:
                
                doCalculation {$1 / $0}
                
                
            case "-"?:
                
                doCalculation {$1 - $0}
                
            case "+"?:
                
                doCalculation {$0 + $1}
            
            
            default:
                break
            
        }
        
        
    }
    
    
    func doCalculation(calculation : (Double, Double) -> Double)
    {
        if operandStack.count >= 2
        {
            displayValue = calculation(self.operandStack.removeLast(),self.operandStack.removeLast())
            returnButtonPressed()
        }
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

